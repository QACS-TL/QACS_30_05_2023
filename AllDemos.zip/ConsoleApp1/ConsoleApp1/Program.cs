﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int counter = 0;
            int a = new int();
            a = 10;
            string s = a.ToString();   

            object o = new object();
            Console.WriteLine(o.ToString());   

            Animal ani = new Animal();
            ani.name = "Bob";
            ani.age = 21;
            Console.WriteLine(ani.pet.petType);


            Animal ani2 = new Animal();
            ani2.name = "Tina";
            ani2.age = 23;

            Console.WriteLine(ani.name);
            Console.WriteLine(ani2.name);

            Console.WriteLine(ani2.ToString());
            Console.WriteLine(ani.ToString());

            List<int> numbers = new List<int>();
            numbers.Add(1);
            numbers.Add(2);
            numbers.Add(3);


            List<Animal> animals= new List<Animal>();
            animals.Add(ani);
            animals.Add(ani2);

            //Feeding Time
            foreach (Animal animal in animals)
            {
                Console.WriteLine(animal.Eat("Sweets"));
                Console.WriteLine(animal.Eat(5));
                Console.WriteLine(animal.Eat("Eggs", "Fanta"));
            }

            Dog dog = new Dog();
            dog.name = "Fido";
            dog.age = 7;
            Pet p = new Pet();
            p.petType = "Rabbit";
            dog.pet = p;
            Console.WriteLine(dog.Eat("Bones"));

            Console.WriteLine($"There are {Animal.count} animals in existence");



        }
    }
}