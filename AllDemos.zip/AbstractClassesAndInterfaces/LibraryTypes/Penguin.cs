using System;
using Interfaces;

namespace LibraryTypes {


    public class Penguin : Bird {

        public Penguin(string name) : base(name) { }

        public override string IsMainCourseDish() {
            return Name + ": " + false;
        }

        public override string DescribeTaste() {
            return Name + ": " + "Chocolaty";
        }

    }


}
