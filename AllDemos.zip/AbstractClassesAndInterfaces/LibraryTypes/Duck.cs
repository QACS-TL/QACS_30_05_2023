using System;
using Interfaces;

namespace LibraryTypes {

    public class Duck : Bird, IInsurable {
        public Duck(string name) : base(name) { }

        public string GetPremium() {
            return Name + ": " + "No premium";
        }
        public string Expires() {
            return Name + ": " + DateTime.Today.ToShortDateString();
        }

    }
}
