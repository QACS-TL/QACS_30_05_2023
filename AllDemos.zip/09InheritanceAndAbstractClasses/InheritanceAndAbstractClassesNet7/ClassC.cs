﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceAndAbstractClasses
{
    //public class ClassC: ClassB //Not allowed because ClassB is sealed (i.e. not inheritable)
    //{
    //}
}
