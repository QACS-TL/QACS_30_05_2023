﻿namespace AnimalFun
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Animal animal1 = new Animal();
            animal1.Name = "F";

            Animal animal2 = new Animal();
            animal2.Name = "Fifi";

            //animal2.SetLimbCount(-1);
            //Console.WriteLine(animal2.GetLimbCount());

            animal2.LimbCount = -1;
            Console.WriteLine(animal2.LimbCount);

            Console.WriteLine(animal1.Move("North", 10));
            Console.WriteLine(animal2.Move("West", 7));

            //Feeding Time
            List<Animal> animals = new List<Animal>();
            animals.Add(animal1);
            animals.Add(animal2);

            foreach(Animal a in animals)
            {
                Console.WriteLine(a.Eat("Biscuits"));
            }


        }
    }
}