﻿namespace AnimalFun
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Animal animal1 = new Animal("Fido", 3);
            //animal1.Name = "Fido";

            Animal animal2 = new Animal("Fifi");
            //animal2.Name = "Fifi";

            //animal2.SetLimbCount(-1);
            //Console.WriteLine(animal2.GetLimbCount());

            //animal2.LimbCount = -1;
            Console.WriteLine(animal2.LimbCount);

            Console.WriteLine(animal1.Move("North", 10));
            Console.WriteLine(animal1.Move(180, 10));
            Console.WriteLine(animal1.Move(directionInDegrees: 180, distance: 10));
            Console.WriteLine(animal1.Move( distance: 50, directionInDegrees: 90));
            Console.WriteLine(animal1.Move("UP"));
            Console.WriteLine(animal2.Move("West", 7));

            //Feeding Time
            List<Animal> animals = new List<Animal>();
            animals.Add(animal1);
            animals.Add(animal2);

            foreach(Animal a in animals)
            {
                Console.WriteLine(a.Eat("Biscuits"));
                Console.WriteLine($"There are currently {Animal.animalCount} animals");
            }


        }
    }
}