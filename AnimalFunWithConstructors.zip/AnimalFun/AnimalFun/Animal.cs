﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalFun
{
    internal class Animal
    {
        public static int animalCount = 0;
        public Animal(string name = "Anonymous", int limbCount = 4)
        {
            this.LimbCount = limbCount;
            this.Name = name;
            animalCount++;
        }

        private int limbCount;

        //The Java Approach:
        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int limbCount)
        //{
        //    if (limbCount < 0)
        //    {
        //        limbCount = 0;
        //    }
        //    this.limbCount = limbCount;
        //}

        //The C# approach (Property)
        public int LimbCount
        {
            get 
            { 
                return limbCount; 
            }
            set 
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value; 
            }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set 
            { 
                if (value.Length < 2)
                {
                    throw new Exception("Illegal Name for an animal!");
                }
                name = value; 
            }
        }

        public int MyProperty { get; set; }

        public string Move(string direction, int distance)
        {
            //Logic to make animal move
            return $"I'm an animal called {name} using my {limbCount} limbs to move {direction} for {distance} metres";
        }
        public string Move(int directionInDegrees, int distance)
        {
            //Logic to make animal move
            return $"I'm an animal called {name} using my {limbCount} limbs to move {directionInDegrees} degrees for {distance} metres";
        }

        public string Move(string direction)
        {
            //Logic to make animal move
            return $"I'm an animal called {name} using my {limbCount} limbs to move {direction}";
        }

        public string Eat(string food)
        {
            //Logic to make animal eat
            return $"I'm an animal called {name} using some of my {limbCount} limbs to eat {food}";
        }
    }
}
