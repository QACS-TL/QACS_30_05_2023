﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalFun
{
    internal class Sloth:Animal
    {
        public Sloth(string name) : this(name, 4)
        {

        }

        public Sloth(string name, int limbCount) : base(name, limbCount)
        {

        }

        public override string Eat(string food)
        {
            return "Hmmm? I'm not hungry, zzzzzzzzzzz";
        }

        public string Sleep(int duration)
        {
            string zzzs = "";
            for (int i = 0; i < duration; i++)
                zzzs += "zzzz";
            return $"I'm a sloth... {zzzs} for {duration} hours";
        }
    }
}
