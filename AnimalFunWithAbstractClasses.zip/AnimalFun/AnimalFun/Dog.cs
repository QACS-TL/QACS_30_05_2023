﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AnimalFun
{
    internal class Dog:Animal
    {
        public Dog(): this("Anon", 5)
        {

        }

        public Dog(string name, int limbCount): base(name, limbCount)
        {

        }

        public string Bark(int numberOfTimes)
        {
            string barks = "";
            for (int i = 0; i < numberOfTimes; i++)
                barks += "woof ";
            return barks;
        }

        public override string Eat(string food)
        {
            //Logic to make dog eat
            return $"I'm a DOG called {Name} using some of my {LimbCount} limbs to GOBBLE {food}";
        }
    }
}
