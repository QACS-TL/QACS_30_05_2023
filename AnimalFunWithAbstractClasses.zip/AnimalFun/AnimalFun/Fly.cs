﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AnimalFun
{
    internal class Fly:Animal
    {
        public string Buzz(int numberOfTimes)
        {
            string zzzs = "";
            for (int i = 0; i < numberOfTimes; i++)
                zzzs += "zzzz";
            return zzzs;
        }

        public override string Move(string direction, int distance)
        {
            //Logic to make animal move
            return base.Move(direction, distance) + " " + Buzz(5);
        }

        public override string Eat(string food)
        {
            //Logic to make fly eat
            return $"I'm a FLY called {Name} using my proboscis to vomit on {food} and then, once digested, suck it back into my body!";
        }

        public override string ToString()
        {
            return $"I'm a Fly called {Name} and I have {LimbCount} limbs";
        }
    }
}
