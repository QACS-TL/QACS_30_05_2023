﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsLibrary
{
    public class LatLongClass
    {
        public double Lat { get; set; }
        public double Long { get; set; }
    }
}
