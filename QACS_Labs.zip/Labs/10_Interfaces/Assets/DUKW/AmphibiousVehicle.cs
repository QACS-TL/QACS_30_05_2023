﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterfaceProject.DUKW
{
    class AmphibiousVehicle : ILandVehicle, IWaterVehicle
    {
    }
}
