﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsLibrary
{
    public class Car
    {
        public Make Make;
        public string RegNumber;

        public Car()
        {
            Count++;
        }

        public static int Count { get; set; }

        public bool Start()
        {
            return true;
        }
    }
}
