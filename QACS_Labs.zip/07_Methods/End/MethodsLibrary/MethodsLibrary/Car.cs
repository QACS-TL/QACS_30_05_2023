﻿namespace MethodsLibrary
{
    public class Car
    {
        public Car()
        {
            Count++;
            engine = new Engine();
        }

        private Engine engine;
        public static int Count = 100;
        public Make Make { get; set; }

        public bool Start()
        {
            return true;
        }
    }
}